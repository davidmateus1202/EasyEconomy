from django.contrib import admin
from .models import Categorias

admin.site.register(Categorias)
