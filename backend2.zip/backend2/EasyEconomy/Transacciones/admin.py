from django.contrib import admin
from .models import Transaccion


admin.site.register(Transaccion)
